#ifndef OPTIBOOT_W25X20CL_H
#define OPTIBOOT_W25X20CL_H

extern uint8_t optiboot_w25x20cl_enter();

#endif /* OPTIBOOT_W25X20CL_H */
