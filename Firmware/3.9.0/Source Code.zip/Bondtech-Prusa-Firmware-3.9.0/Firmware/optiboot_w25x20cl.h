#ifndef OPTIBOOT_W25X20CL_H
#define OPTIBOOT_W25X20CL_H

extern void optiboot_w25x20cl_enter();

#endif /* OPTIBOOT_W25X20CL_H */
