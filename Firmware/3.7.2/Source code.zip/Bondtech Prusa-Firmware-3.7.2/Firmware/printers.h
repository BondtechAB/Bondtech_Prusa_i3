#ifndef PRINTERS_H
#define PRINTERS_H

#define PRINTER_UNKNOWN 0

#define PRINTER_MK1         100
#define PRINTER_MK2         200
#define PRINTER_MK2_SNMM    201
#define PRINTER_MK25        250
#define PRINTER_MK25_SNMM   251
#define PRINTER_MK25S		252
#define PRINTER_MK3         300
#define PRINTER_MK3_SNMM    301
#define PRINTER_MK3S		302

#endif //PRINTERS_H
