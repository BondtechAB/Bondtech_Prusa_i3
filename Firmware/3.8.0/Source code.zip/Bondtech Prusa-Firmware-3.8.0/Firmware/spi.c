//spi.c - hardware SPI
//#ifdef __SPI

#include "spi.h"
#include <avr/io.h>


//#endif //__SPI
